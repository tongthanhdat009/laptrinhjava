package GUI;
//file khởi tạo giao diện

public class MAIN {
    public static void main(String[] args){
        new GUILogin();
    }
}
